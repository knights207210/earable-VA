./loreta.sh loreta-epoc.cfg AF3 F7 F3 FC5 T7/T3 P7/T5 O1 O2 P8/T6 T8/T4 FC6 F4 F8 AF4
