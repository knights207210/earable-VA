This folder contains configuration files created by the SSVEP scenarios.
