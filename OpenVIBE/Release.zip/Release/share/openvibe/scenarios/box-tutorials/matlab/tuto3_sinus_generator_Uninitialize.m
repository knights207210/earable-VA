% tuto3_sinus_generator_Uninitialize.m
% -------------------------------
% Author : Laurent Bonnet (INRIA)
% Date   : 25 May 2012
%
% The function tuto3_sinus_generator_Uninitialize is called when pressing 'stop' in the scenario.
% 
function box_out = tuto3_sinus_generator_Uninitialize(box_in)
    disp('Uninitializing the box...')
		
    box_out = box_in;

end
    