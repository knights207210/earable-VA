#ifndef __OpenViBE_Notes_H__
#define __OpenViBE_Notes_H__

/*
 * Gestion du temps en milisecondes sur uint32 => 49+ jours
 * Gestion du temps en secondes sur uint64 32:32 => 100+ ans
 */

#endif // __OpenViBE_Notes_H__
