#ifndef __OpenViBE_Base_H__
#define __OpenViBE_Base_H__

#include "ov_defines.h"
#include "ov_types.h"
#include "ov_notes.h"

#endif // __OpenViBE_Base_H__
