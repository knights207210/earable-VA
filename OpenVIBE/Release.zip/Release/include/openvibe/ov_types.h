#ifndef __OpenViBE_Types_H__
#define __OpenViBE_Types_H__

#define OV_APPEND_TO_NAMESPACE OpenViBE
#include <ov_common_types.h>
#undef OV_APPEND_TO_NAMESPACE


#endif // __OpenViBE_Types_H__
