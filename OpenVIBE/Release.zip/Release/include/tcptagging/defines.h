#ifndef __Socket_Defines_H__
#define __Socket_Defines_H__

#include <ov_common_defines.h>

#define OV_APPEND_TO_NAMESPACE TCPTagging
#include <ov_common_types.h>
#undef OV_APPEND_TO_NAMESPACE


#endif // __Socket_Defines_H__
